fx_version 'bodacious'
game 'gta5'

client_script 'Client.net.dll'

server_scripts {
    'Server.net.dll',
    'transmission.lua'
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/sounds/*.ogg'
}